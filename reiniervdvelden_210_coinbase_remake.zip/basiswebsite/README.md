# Procesverslag






## Jij

<details>
<summary></summary>

### Auteur:
Reinier van der Velden

#### Je startniveau:
Rode piste

#### Je focus:
responsive

</details>





## Je website

<details>
<summary></summary>

### Je opdracht:
Ik ga coinbase proberen na te maken:
https://www.coinbase.com/

#### Screenshot(s) van de eerste pagina (small screen):
hier de naam van de pagina  
<img src="images/small_screen_home.png" width="375px" alt="omschrijving van de pagina">

#### Screenshot(s) van de tweede pagina (small screen):
hier de naam van de pagina  
<img src="images/small_screen_learn.png" width="375px" alt="omschrijving van de pagina">

</details>





## Breakdownschets (week 1)

<details>
<summary></summary>

### de hele pagina:
<img src="images/breakdown.png" width="375px" alt="breakdown van de hele pagina">



</details>





## Voortgang 1 (week 2)

<details>
<summary></summary>

### Stand van zaken
Het gaat opzich best goed, Ik ben bezig de home pagina ben al wel over de helft. Ik maak alles meteen responsive omdat ik denk dat dit makkelijker is.



### Verslag van meeting
hier na afloop snel de uitkomsten van de meeting vastleggen

- We hadden met ze alle besproken waar iedereen vast liep, Zelf had ik moeite met een hover effect de assistenten hebben mij hier goed mee geholpen om dit alsnof voor elkaar te krijgen.
Verder ging bij mij alles wel goed. ik ga proberen de eerste pagina komende week af te maken.


</details>





## Voortgang 2 (week 3)

<details>
<summary></summary>

### Stand van zaken
Het gaat  goed ik heb nu bijna de homepage af met de content die ik erop wil hebben. Er zijn alleen nog een paar dingen die ik moet fixen voor het responsive gedeelte.

<img src="images/landing_page.png" width="375px" alt="landing page zelf gemaakt">
<img src="images/home_page_2.png" width="375px" alt="verdere info homepage">

Om live te zien waar ik momenteel mee bezig ben is hier de link van mijn website. Ik zorg ervoor dat ik deze regelmatig update.
https://oege.ie.hva.nl/~veldenr4/coinbase_schoolproject/



### Verslag van meeting
hier na afloop snel de uitkomsten van de meeting vastleggen

- Ik had zelf niet echt punten die ik moest bespreken ik vond het wel fijn om mijn werk te laten zien zodat ik toch op die manier weet of ik de goeie richting op ging

</details>





## Toegankelijkheidstest (week 4)

<details>
<summary></summary>

### Bevindingen
Ondanks dat voor ons het testen leuk was om te doen zit er natuurlijk ook een serieuze kant aan aangezien er mensen zijn die daadwerkelijk zulke beperkingen hebben.
Dit zijn mijn bevinden die ik heb ondervonden/ ervaren

Er waren speciale brillen die je kon opdoen en verschillende soorten "effecten" kreeg, ik had niet alle brillen uitgetest maar wel een paar.
- bril met gele glazen
- Suikerziekte brillen
- bril met een stip in het midden

Ik had ook gebruik gemaakt van de balon hooghouden om op die manier iemand met een lage concentratie te ervaren.

Tot slot had ik het schokband om. Dit was een hele ervaring  

#### Verschillende brillen bevindingen.
- bril met gele glazen:
Deze bril was naar mijn mening het minst erg omdat je eigenlijk nog alles kon zien alleen vielen sommige kleuren weg. En op plekken waar geen goed contrast was moeilijk te lezen/zien.

De oplossing is denk ik erg simpel door te zorgen dat je goed contrast hebt.

- suikerziekte brillen:
Het nadeel van deze bril was dat je letterlijk sommige delen van je website niet meer kon zien. Ik hoop voor mensen met suikerziekte dat ze altijd optijd zijn met insuline inspuiten want dat zicht was niet prettig en hoop je dat niemand krijgt als het voorkomen kan worden.

- bril met stip in het midden:
Deze bril was moeilijk want je kon niet echt het midden punt zien van de website. Ook in mijn geval bij coinbase soms het menu niet.

Ik denk dat de oplossing hiervoor kan zijn is na te denken over een design waarbij bijv het menu aan de zeikant zit.

<img src="images/brillen.png" width="375px" alt="gekke brillen op je hoofd">


#### Balon hooghouden.
op mijn eigen site was het nog niet te moeite om dit te gaan testen wel ben ik gaan testen om bijvoorbeeld een berichtje te typen terwijl je de balon moet hooghouden dit was nog al een opgave... bijzonder om te zien dat je denkt het lukt makkelijk maar dat dat toch wel moeilijk blijkt te zijn

#### schokband.
Dit was een hele vreemde ervaring om geen controlle meer te hebben over je spieren.
Ik probeerde te scrollen op me site maar zelfs dat lukte me eigenlijk niet omdat ik bijna niet de touchpad normaal kon aanraken. Ik denk dat hiervoor de beste oplossing is als je zorgt dat je kan scrollen met de pijltjes toetsten of misschien wel voice controll aanzetten op de laptop / mobiel

<img src="images/schokband.png" width="375px" alt="schokken door je lichaam">
<img src="images/schokband_scroll.png" width="375px" alt="niet kunnen scrollen door de schokken">





</details>





## Voortgang 3 (week 4)

<details>
<summary></summary>

### Stand van zaken
Alles verloopt goed ik moest alleen bij me learn pagina een section maken met 2 elementen boven en 4 onder. De assistenten zeiden dat dit het makkelijkste was met grid. Ik vond dit wel moeilijk maar het is me uiteindelijk gelukt. Ik heb hier ook nog even hulp bij gekregen van de assistent (Rowin Schmidt).
Ook had ik problemen met mijn svg animatie dit bleek een hele makkelijke oplossing te hebben door alleen maar het word forwards erbij te zetten.



### Verslag van meeting

dit heb ik opgestoken van deze voortgang.
- Learn pagina sectie met grid maken
- als een svg animatie niet wil stoppen maak gebruik van forwards ( tot einde en verder niet)


</details>





## Eindgesprek (week 5)

<details>
<summary></summary>

### Eind praatje
ik vond FED een leuk vak om te doen, met name de aanpak van de lessen / eindopdracht. Leren door te doen falen doen en nog eens falen. Zelf ben ik hier een groot voorstander van.

Ondanks dat ik hiervoor de opleiding web en applicatie ontwikkelaar heb gedaan. Heb ik zelf ook nog dingen geleerd denk aan: Grid, Root, kleine svg animaties. De basis kon ik al dus dat hielp zeker mee. Ook vond ik het leuk om andere klasgenoten te helpen met hun projecten en te zien wat zij hadden gemaakt

Wat extra's:
Druk op de enter knop en let op de coin naast "jump start your crypto portfolio".
Mocht je liever een laserstraal zien druk dan op 0.

De link naar mijn eindproduct:
https://oege.ie.hva.nl/~veldenr4/coinbase_schoolproject/
### Screenshot(s)



foto van me eindproduct:
<img src="images/homescherm_klaar.png" width="250px" alt="eindproduct foto">

</details>





## Bronnenlijst

<details s>
<summary>continu bijhouden terwijl je werkt</summary>


1. w3 schools - IK heb hier gekeken voor kleine dingen
2. stack overflow. combine hover with after https://stackoverflow.com/questions/13233991/combine-after-with-hover
3. css - tricks grid. https://css-tricks.com/snippets/css/complete-guide-grid/

</details>
